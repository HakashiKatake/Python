def greatestnumber(a,b,c):
    return max(a,b,c)

print(greatestnumber(10,20,30))


